import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Show implements ActionListener{
	Label bill;
	JLabel reg;
	JTextField tr;
	Button gen,paid;
	TextArea out;
	Connect obj=new Connect();
	
	public Show() {
	    JFrame fr=new JFrame();
	    JPanel pn=new JPanel();
	    fr.setSize(400,400);
	    fr.add(pn);
	    pn.setBackground(Color.gray);
	    pn.setLayout(null);
	    
	    bill=new Label("Bill Detail");
	    bill.setBounds(10, 10, 70, 20);
	    pn.add(bill);
	    	    
	    reg=new JLabel("Register Number: ");
	    reg.setBounds(10, 50, 150,20);;
	    pn.add(reg);
	    
	    tr=new JTextField();
	    tr.setBounds(150,50,150,25);
	    pn.add(tr);
	    
	    gen=new Button("Generate Amount");
	    gen.setBounds(170, 90, 100,15);;
	    pn.add(gen);
	    
	    paid=new Button("Fees Paid");
	    paid.setBounds(150, 250, 100, 15);
	    pn.add(paid);
	    
	    out=new TextArea();
	    out.setBounds(10, 120, 370, 100);
	    out.setEditable(false);
	    pn.add(out);
	    
	    fr.setVisible(true);
	    
	    gen.addActionListener(this);
	    paid.addActionListener(this);

	}

	public void actionPerformed(ActionEvent e) {
		int inpreg=Integer.parseInt(tr.getText());
		obj.billFees();
		String outString=obj.stdData("stdata",inpreg);
		if(e.getSource()==gen) {
			out.setText("Reg No    Name      Category    Days   Bill Amount    Due\n"+outString);
		}
		if(e.getSource()==paid) {
			obj.feesPaid(inpreg);
			out.setText("Reg No    Name      Category    Days   Bill Amount    Due\n"+outString);
		}
	}
	
	/*public static void main(String args[]) {
		new Show();
	}*/
	
}