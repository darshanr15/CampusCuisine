import java.awt.*;
import java.awt.event.*;

import javax.swing.JPanel;

class Student extends Frame implements ActionListener
{
	private static final long serialVersionUID = 1L;
	Label lsname, lsrollno, lsclass, lcat, lsbg, lsmob;
	CheckboxGroup category;
	Checkbox veg, nonveg;
	Choice csclass;
	TextField tfsname, tfsrollno, tfsmob;
	Button submit;
	String name;
	JPanel pn;
	int reg,cat;
	TextArea display_details;

	Student()
	{	
		pn = new JPanel();
	    pn.setBackground(Color.gray);
	    add(pn);
		lsname   = new Label("Name : ");
		lsrollno = new Label("Roll No : ");
		lsclass  = new Label("Year : ");
		lcat  = new Label("Category : ");
		lsmob    = new Label("Mobile : ");

		category = new CheckboxGroup();  
        veg  = new Checkbox("Veg", category, false);   
        nonveg = new Checkbox("NonVeg", category, false);  

        csclass = new Choice();  
        csclass.add("1st Year");  
        csclass.add("2nd Year");  
        csclass.add("3rd Year");  
        csclass.add("4th Year");  

		tfsname   = new TextField();
		tfsrollno = new TextField();
		tfsmob    = new TextField();

		submit  = new Button("Submit");

		display_details = new TextArea("", 2 , 100 , TextArea.SCROLLBARS_NONE);
		display_details.setEditable(false);

		lsname.setBounds(10, 30, 50, 20);
		tfsname.setBounds(70, 30, 150, 20);
		
		lsrollno.setBounds(240, 30, 50, 20);
		tfsrollno.setBounds(300, 30, 150, 20);
		
		lsclass.setBounds(10, 60, 50, 20);
		csclass.setBounds(70, 60, 150, 20);
		
		lcat.setBounds(240, 60, 50, 20);
		veg.setBounds(300, 60, 50, 20);
		nonveg.setBounds(360, 60, 50, 20);
		
		lsmob.setBounds(10, 90, 50, 20);
		tfsmob.setBounds(70, 90, 150, 20);

		submit.setBounds(10, 200, 440, 30);

		display_details.setBounds(10, 240, 440, 130);

		add(lsname);
		add(lsrollno);
		add(lsclass);
		add(lcat);
		add(lsmob);

		add(veg);
		add(nonveg);

		add(csclass);

		add(tfsname);
		add(tfsrollno);
		add(tfsmob);

		add(submit);

		add(display_details);

		submit.addActionListener(this);

		setTitle("Student Registeration");
		setSize(460,390);
		setLayout(null);
		setVisible(true);

		addWindowListener(new WindowAdapter()
		{  
            public void windowClosing(WindowEvent e)
            {  
                dispose();  
            }  
        });
	}

	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==submit)
		{
			Connect obj = new Connect();
			name=tfsname.getText();
			reg=Integer.parseInt(tfsrollno.getText());
			String s=(category.getSelectedCheckbox().getLabel());
			if(s.equals("Veg")) cat=0;
			else cat=1;
			String sdetails = " **Successfully Registered**\nName : " + tfsname.getText() + "\nReg No. : " + tfsrollno.getText() + "\nYear : " + csclass.getSelectedItem() + "\nCategory : " + category.getSelectedCheckbox().getLabel() + "\nMobile : " + tfsmob.getText();
			display_details.setText(sdetails);
			obj.insertData(reg,name,cat);
			obj.retrieveData("stdata");
		}
	}

	public static void main(String[] args)
	{
		new Student();
	}
}