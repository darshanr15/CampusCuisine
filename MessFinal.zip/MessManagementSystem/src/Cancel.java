import java.awt.Button;
import java.awt.Color;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Cancel implements ActionListener {
	Button button;
	Label user,pass;
	JTextField t,t1;
	TextArea out;
	String from;
	int days,r;
	Connect obj=new Connect();
	
	public Cancel(int reg){
		r=reg;
	    JFrame fr=new JFrame();
	    JPanel pn=new JPanel();
	    fr.setSize(400,300);
	    fr.add(pn);
	    pn.setBackground(Color.gray);
	    pn.setLayout(null);
	    
	    JLabel note=new JLabel("Note: Once the cancellation is confirmed");
	    note.setBounds(10,10,400,20);
	    pn.add(note);
	    JLabel note1=new JLabel("Students cannot avail the Mess Service for the Mentioned Days.");
	    note1.setBounds(10,30,400,20);
	    pn.add(note1);
	    user=new Label("No of Days: ");
	    user.setBounds(30,70,100,25);
	    pn.add(user);
	    pass=new Label("From (dd/mm/yy): ");
	    pass.setBounds(30,100,100,25);
	    pn.add(pass);
	    t=new JTextField();
	    t.setBounds(150,70,100,20);
	    pn.add(t);
	    t1=new JTextField();
	    t1.setBounds(150,100,100,20);
	    pn.add(t1);
	    
	    button=new Button("Confirm");
	    button.setBounds(270, 85, 80, 20);
	    pn.add(button);
	    
	    out=new TextArea("", 2 , 100 , TextArea.SCROLLBARS_NONE);
	    out.setBounds(50, 140, 300, 70);
	    out.setEditable(false);
	    pn.add(out);
	    
	    fr.setVisible(true);
	    
	    button.addActionListener(this);
}
	
	/*public static void main(String args[]) {
		new Cancel(21);
		
	}*/

	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==button) {
			days=Integer.parseInt(t.getText());
			from=t1.getText();
			out.setText("Mess has been Cancelled for "+days+" days.");
			obj.updateDays(r, days);
			}
	}
}