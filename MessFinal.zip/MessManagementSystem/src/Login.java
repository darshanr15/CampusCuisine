import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login implements ActionListener{
	JButton button;
	JLabel user,pass,inv;
	JLabel img;
	JTextField t;
	JFrame fr;
	JPasswordField tf1;
	Connect objConnect=new Connect();
	
	public Login() {
	    fr=new JFrame();
	    JPanel pn=new JPanel();
	    fr.setSize(400,200);
	    fr.add(pn);
	    pn.setBackground(Color.gray);
	    pn.setLayout(null);

	    user=new JLabel("Username: ");
	    user.setBounds(30,20,100,25);
	    pn.add(user);
	    pass=new JLabel("Password: ");
	    pass.setBounds(30,60,100,25);
	    pn.add(pass);
	    inv=new JLabel("");
	    inv.setBounds(70,117,150,25);
	    pn.add(inv);
	    
	    t=new JTextField();
	    t.setBounds(200,20,150,25);
	    pn.add(t);
	    tf1=new JPasswordField();
	    tf1.setBounds(200,60,150,25);
	    pn.add(tf1);

	    button=new JButton("SIGN IN");
	    button.setBounds(220,120,100,20);
	    pn.add(button);
	    
	    button.addActionListener(this);
	    
	    fr.setVisible(true);
	}

  public static void main(String args[]){
	  new Login();
  }

public void actionPerformed(ActionEvent e) {
	String uname;
	String pass;
	uname=t.getText();
	String data=objConnect.showData();
	pass=String.valueOf(tf1.getPassword());
	if(uname.contentEquals("admin") && pass.contentEquals("admin")){
	new Admin();
	}
	else if(data.indexOf(uname)!=-1 && pass.contentEquals("student")) {
	new StdPage(uname);
	}
	else {
	inv.setText("Invalid Credentials!");
	}
}
}