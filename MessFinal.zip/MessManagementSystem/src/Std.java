import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Std implements ActionListener {
	
	JLabel det;
	TextArea out;
	Button reset;
	Connect con=new Connect();
	
	public Std() {
		JFrame fr=new JFrame();
	    JPanel pn=new JPanel();
	    fr.setSize(400,400);
	    fr.add(pn);
	    pn.setBackground(Color.gray);
	    pn.setLayout(null);
		
	    det=new JLabel("Student Database");
	    det.setFont(new Font("Calibri", Font.BOLD, 18));
	    det.setBounds(10, 15, 150, 20);
	    pn.add(det);
	    
	    reset = new Button("Reset");
	    reset.setBounds(300, 15, 75, 20);
		pn.add(reset);
	    
	    out=new TextArea();
	    out.setBounds(10, 50, 370, 300);
	    out.setEditable(false);
	    pn.add(out);
	    
	    String data=con.showData();
	    out.setText("   RegNo    |     Name     |  Fees Due\n\n"+data);
	    
	    fr.setVisible(true);
	    
	    reset.addActionListener(this);
	}
	public static void main() {
		new Std();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==reset)
			con.reset();
	}
}
