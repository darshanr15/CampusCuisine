import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Fees implements ActionListener{
	JLabel bill;
	Label user,cat,reg;
	JTextField tr;
	Button gen;
	TextArea out;
	int r;
	Connect obj=new Connect();
	String namedetail;
	
	public Fees(int re) {
		r=re;
		namedetail=obj.name("stdata", r);
	    JFrame fr=new JFrame();
	    JPanel pn=new JPanel();
	    fr.setSize(400,400);
	    fr.add(pn);
	    pn.setBackground(Color.gray);
	    pn.setLayout(null);
	    
	    bill=new JLabel("Bill Detail");
	    bill.setBounds(10, 10, 70, 20);
	    pn.add(bill);
	    
	    user=new Label("Name: "+namedetail);
	    user.setBounds(10,30,100,25);
	    pn.add(user);
	    reg=new Label("Reg No: "+r);
	    reg.setBounds(10,50,100,25);
	    pn.add(reg);
	    
	    gen=new Button("Generate Amount");
	    gen.setBounds(150, 90, 100,20);;
	    pn.add(gen);
	    
	    out=new TextArea();
	    out.setBounds(10, 120, 370, 100);
	    out.setEditable(false);
	    pn.add(out);
	    
	    fr.setVisible(true);
	    
	    gen.addActionListener(this);
		obj.billFees();

	}

	public void actionPerformed(ActionEvent e) {
		String outString=obj.stdData("stdata",r);
		if(e.getSource()==gen) {
			out.setText(" Reg No        Name       Category      Days    Bill Amount     Due\n"+outString);
		}
	}
	
	/*public static void main(String args[]) {
		new Fees(10);
	}*/
	
}