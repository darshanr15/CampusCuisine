import java.awt.Button;
import java.awt.Color;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class StdPage implements ActionListener 
{
	JFrame fr;
	Button bill,cancel,menu,home;
	Label user,pass,cat;
	JLabel line;
	int r;
	static Connect obj= new Connect();
	
	public StdPage(String uname) {
	r=Integer.parseInt(uname);
	String namedetail=obj.name("stdata", r);
	
		fr=new JFrame();
	    JPanel pn=new JPanel();
	    fr.setSize(400,300);
	    fr.add(pn);
	    pn.setBackground(Color.gray);
	    pn.setLayout(null);

	    user=new Label("Name: "+namedetail);
	    user.setBounds(10,10,100,25);
	    pn.add(user);
	    pass=new Label("Reg No: "+r);
	    pass.setBounds(10,30,100,25);
	    pn.add(pass);
	    
	    line=new JLabel("--------------------------------------------------------------------------------------------------");
	    line.setBounds(0, 55, 400, 10);
	    pn.add(line);
	    bill =new Button("Generate Bill");
		bill.setBounds(150,120,100,20);
		pn.add(bill);
		
		cancel=new Button("Cancellation");
		cancel.setBounds(150,170,100,20);
		pn.add(cancel);
		
		menu=new Button("Food Menu");
		menu.setBounds(150,220,100,20);
		pn.add(menu);
		home=new Button("<- Back To Main Page");
		home.setBounds(10, 70, 150, 20);
		pn.add(home);
		
	    fr.setVisible(true);
	    
	    bill.addActionListener(this);
	    cancel.addActionListener(this);
	    menu.addActionListener(this);
	    home.addActionListener(this);
	}
	
	/*public static void main(String args[]) {
		new StdPage("21");
	}*/

	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bill) {
			new Fees(r);
		}
		else if(e.getSource()==cancel) {
			new Cancel(r);
		}
		else if(e.getSource()==menu) {
			new FoodMenu();
		}
		else if(e.getSource()==home) {
			fr.dispose();
			new Login();
		}
	}
	}
