import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Connect {
	/*public static void main(String args[]) {
		Connect obj= new Connect();
		obj.retrieveData("stdata");
		obj.feesPaid(52);
}
		//obj.insertData(42,"Cave",1);
		//obj.updateDays(52, 4);
		obj.reset();
		obj.billFees();
		//obj.retrieveData("stdata");
		obj.showData();
	}
    */
    public void retrieveData(String tablename){
        try{   
            Connection con=DriverManager.getConnection(  
            "jdbc:mysql://localhost:3306","root","admin");   
            Statement stmt=con.createStatement();  
            stmt.executeUpdate("use mess");
            ResultSet rs=stmt.executeQuery("select * from "+tablename);
                 
            while(rs.next()){
                int count=1;
                while (true){
                    try{
                        System.out.print(rs.getString(count)+" ");
                        count++;
                    }
                    catch(Exception e){
                        System.out.println("");
                        break;
                    }
                }     
            }
            con.close();  
         }
        catch(Exception e){
                System.out.println(e);
        }  
    }
    
    public void insertData(int Reg,String Name,int Cat) {
        String n="N-Veg";
        String n1="Veg";
    	try{   
            Connection con=DriverManager.getConnection(  
            "jdbc:mysql://localhost:3306","root","admin");   
            Statement stmt=con.createStatement();  
            stmt.executeUpdate("use mess");
            if(Cat==1)
            stmt.executeUpdate("insert into stdata values("+Reg+",'"+Name+"','"+n+"',"+31+","+0+","+0+")");
            else {
            	stmt.executeUpdate("insert into stdata values("+Reg+",'"+Name+"','"+n1+"',"+31+","+0+","+0+")");
			}
            con.close();  
        }
    	catch(Exception e){
                System.out.println(e);
        }  
    }
    
    public void updateDays(int Reg,int Day) {
    	try{   
            Connection con=DriverManager.getConnection(  
            "jdbc:mysql://localhost:3306","root","admin");   
            Statement stmt=con.createStatement();  
            stmt.executeUpdate("use mess");
            stmt.executeUpdate("update stdata set Days=Days-"+Day+" where RegNo="+Reg);
            con.close();  
        }
    	catch(Exception e){
                System.out.println(e);
        }
    }
    	
     public void billFees() {
    	  /*Date date = new Date();
          SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
          String str = formatter.format(date);*/
          //int m=Integer.parseInt(str.substring(3,5))-1;
          //int d=Integer.parseInt(str.substring(0,2));
    	 try{   
             Connection con=DriverManager.getConnection(  
             "jdbc:mysql://localhost:3306","root","admin");   
             Statement stmt=con.createStatement();  
             stmt.executeUpdate("use mess");
             stmt.executeUpdate("update stdata set Fees=Days*110 where Category='N-Veg'");
             stmt.executeUpdate("update stdata set Fees=Days*80 where Category='Veg'");
             con.close();
         }
    	 catch(Exception e){
                 System.out.println(e);
         	}
     	}
     
     public void reset() {
    	 Date date = new Date();
         SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
         String str = formatter.format(date);
         int m=Integer.parseInt(str.substring(3,5))-1;
    	 try{   
             Connection con=DriverManager.getConnection(  
             "jdbc:mysql://localhost:3306","root","admin");   
             Statement stmt=con.createStatement();  
             stmt.executeUpdate("use mess");
             stmt.executeUpdate("update stdata set Due=0");
             if(m==1||m==3||m==5||m==7||m==8||m==10||m==0)
             stmt.executeUpdate("update stdata set Days=31");
             else if(m==2)
             stmt.executeUpdate("update stdata set Days=29");
             else 
             stmt.executeUpdate("update stdata set Days=30");
             con.close();
         }
    	 catch(Exception e){
                 System.out.println(e);
         	}
     }
     
     public String showData() {
    	 String out="     ";
    	 try{   
             Connection con=DriverManager.getConnection(  
             "jdbc:mysql://localhost:3306","root","admin");   
             Statement stmt=con.createStatement();  
             stmt.executeUpdate("use mess");
             ResultSet rs=stmt.executeQuery("select RegNo,Name,Due from stdata");
             while(rs.next()){
                 int count=1;
                 while (true){
                     try{
                    	 if(count%3==0)
                    	 out=out+rs.getString(count)+ "    \n     ";
                    	 else
                    	 out=out+rs.getString(count)+ "     |    ";
                         count++;
                     }
                     catch(Exception e){
                         System.out.println("");
                         break;
                     }
                 }     
             }
             con.close();  
          }
         catch(Exception e){
                 System.out.println(e);
         }
    	 return out;
     }

	public String stdData(String tablename,int reg) {
        String out = "  ";
		try{   
            Connection con=DriverManager.getConnection(  
            "jdbc:mysql://localhost:3306","root","admin");   
            Statement stmt=con.createStatement();  
            stmt.executeUpdate("use mess");
            ResultSet rs=stmt.executeQuery("select * from "+tablename+" where RegNo="+reg);
            while(rs.next()){
                int count=1;
                while (true){
                    try{
                    	out=out+rs.getString(count)+"            ";
                    	count++;
                    }
                    catch(Exception e){
                        System.out.println("");
                        break;
                    }
                }     
            }
            con.close();  
         }
        catch(Exception e){
                System.out.println(e);
        } 
		return out;
	}
	
	public String name(String tablename,int reg) {
		String out="";
		try{   
            Connection con=DriverManager.getConnection(  
            "jdbc:mysql://localhost:3306","root","admin");   
            Statement stmt=con.createStatement();  
            stmt.executeUpdate("use mess");
            ResultSet rs=stmt.executeQuery("select Name from "+tablename+" where RegNo="+reg);
            while(rs.next()){
                int count=1;
                while (true){
                    try{
                    	if(out!=null) {
                    	out=out+rs.getString(count);
                    	count++;
                    	}
                    }
                    catch(Exception e){
                        System.out.println("");
                        break;
                    }
                }     
            }
            con.close();  
         }
        catch(Exception e){
                System.out.println(e);
        } 
		return out;
	}

	public void feesPaid(int reg) {
		 try{   
             Connection con=DriverManager.getConnection(  
             "jdbc:mysql://localhost:3306","root","admin");   
             Statement stmt=con.createStatement();  
             stmt.executeUpdate("use mess");
             stmt.executeUpdate("update stdata set Due=1 where RegNo="+reg);
             con.close();
         }
    	 catch(Exception e){
                 System.out.println(e);
         	}
	}
	}
