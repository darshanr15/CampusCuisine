import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Admin implements ActionListener{
	JFrame fr;
	Button bill,reg,data,menu,home;
	static Connect obj= new Connect(); 

	public Admin() {
		fr=new JFrame();
	    JPanel pn=new JPanel();
	    fr.setSize(400,250);
	    fr.add(pn);
	    pn.setBackground(Color.gray);

	    pn.setLayout(null);
		bill =new Button("Generate Bill");
		bill.setBounds(150,50,100,20);
		pn.add(bill);
		reg=new Button("Add Student");
		reg.setBounds(150,90,100,20);
		pn.add(reg);
		data=new Button("Student Details");
		data.setBounds(150,130,100,20);
		pn.add(data);
		menu=new Button("Food Menu");
		menu.setBounds(150,170,100,20);
		pn.add(menu);
		home=new Button("<- Back To Main Page");
		home.setBounds(20, 10, 150, 20);
		pn.add(home);
		
		fr.setVisible(true);
		
		bill.addActionListener(this);
		reg.addActionListener(this);
		data.addActionListener(this);
		menu.addActionListener(this);
		home.addActionListener(this);
	}
	public static void main(String args[]) {
		new Admin();
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bill) {
			obj.billFees();
			new Show();
		}
		else if(e.getSource()==reg) {
			new Student();
		}
		else if(e.getSource()==data) {
			new Std();
		}
		else if(e.getSource()==menu) {
			new FoodMenu();
		}
		else if(e.getSource()==home) {
			fr.dispose();
			new Login();		}
	}
}
