import javax.swing.*;
import java.awt.*;
@SuppressWarnings("serial")

public class FoodMenu extends JFrame {
    public FoodMenu() {
        JFrame frame = new JFrame(); //JFrame Creation       
        frame.setSize(800,600);
        frame.getContentPane().setLayout(null);
        
        JLabel men=new JLabel("FOOD MENU SCHEDULE");
        men.setBounds(10, 10, 200, 20);
        frame.add(men);
        JLabel label = new JLabel(); //JLabel Creation
        ImageIcon imgIcon=new ImageIcon(this.getClass().getResource("/menu2.jpg"));
        label.setIcon(imgIcon); //Sets the image to be displayed as an icon
        Dimension size = label.getPreferredSize(); //Gets the size of the image
        label.setBounds(10, 50, size.width, size.height); //Sets the location of the image
        
        frame.getContentPane().add(label);
        frame.setBackground(Color.gray);
        frame.setVisible(true); // Exhibit the frame
    }
    
   /* public static void main(String args[]) {
		new FoodMenu();
	}*/
}
